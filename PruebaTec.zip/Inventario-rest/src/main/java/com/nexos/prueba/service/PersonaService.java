package com.nexos.prueba.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexos.prueba.model.Persona;
import com.nexos.prueba.repository.PersonaResporitory;
/*
 * autor: Sebastian Silva
 * 
 * objetivo: Este es nuestro service, que se encarga de cada una de las operaciones que queramos 
 * realizar, en este caso son consultas a una bd postgres 
 * 
 */
@Service
public class PersonaService {

	@Autowired
	private PersonaResporitory personaResporitory;
	
	
	public Persona create (Persona persona) {
		return personaResporitory.save(persona);
	}
	
	public List<Persona> getAllPersonas (){
		return personaResporitory.findAll();
	}
	
	public void delete (Long id) {
		personaResporitory.deleteById(id);
	}
	
	public Optional<Persona> findById (Long id) {
		return personaResporitory.findById(id);
	}
	
	public Persona edit(Persona persona) {
		return personaResporitory.save(persona);
	}
	
}
