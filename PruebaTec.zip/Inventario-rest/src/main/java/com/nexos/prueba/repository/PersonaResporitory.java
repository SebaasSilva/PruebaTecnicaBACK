package com.nexos.prueba.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nexos.prueba.model.Persona;

public interface PersonaResporitory extends JpaRepository<Persona, Long>{

}
