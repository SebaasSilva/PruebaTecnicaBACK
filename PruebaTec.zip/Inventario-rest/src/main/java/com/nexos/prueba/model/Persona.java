package com.nexos.prueba.model;
import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

import javax.persistence.*;
/*
 * autor: Sebastian Silva
 * 
 * objetivo: Esta es nuestra entidad, que nos permite identificar la relacion y
 * cada uno de los campos de la tabla.
 * 
 * 
 * 
 * 
 */
@Entity
@Table (name = "personas")
public class Persona {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String nombre;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date fecha;
	private Long codigo;
	private String numeroTarjeta;
	
	
	public Persona() {
		
	}


	public Persona(Long id, String nombre, Date fecha, Long codigo, String numeroTarjeta) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.fecha = fecha;
		this.codigo = codigo;
		this.numeroTarjeta = numeroTarjeta;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	public Date getFecha() {
		return fecha;
	}


	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	public Long getCodigo() {
		return codigo;
	}


	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}


	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}


	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}
	
	
	
}
