package com.nexos.prueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
